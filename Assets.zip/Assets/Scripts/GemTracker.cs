﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

namespace UnityStandardAssets._2D
{
    public class GemTracker : MonoBehaviour
    {
        public int startGems = 0;
        public int numGems = 3;
        public int srtGems = 1;
        public Text gems;
        public int curGems = 0;
        private int totalGems = 0;
        AudioSource playerAudio;
        public GemBag gemCount;

        PlayerCollision getCollision;
        // Start is called before the first frame update
        void Awake()
        {
            playerAudio = GetComponent<AudioSource>();
            getCollision = GetComponent<PlayerCollision>();
            gemCount = gemCount.GetComponent<GemBag>();
            gems = gems.GetComponent<Text>();
            

            if (gems == null)
            {
                Debug.LogError("No Text component found.");  
            }
        }

        // Update is called once per frame
        void Update()
        {
            gems.text = curGems.ToString();
        }

        public void GemCollect(int addGems)
        {
            if(addGems != -1)
            {
                curGems += addGems;
                gemCount.GemUpdate(curGems);
            }
            else
            {
                curGems = 0;
            }
        }

        public void TotalGems(int dump)
        {
            if(dump == 1)
            {
                totalGems += curGems;
            }

            if(totalGems >= numGems)
            {
                //Win Condition
            }
        }

    }
}
