﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace UnityStandardAssets._2D
{
    public class GemBag : MonoBehaviour
    {
        public int gems = 0;
        // Start is called before the first frame update
        void Start()
        {
            
        }

        // Update is called once per frame
        public void GemUpdate(int amount)
        {
            gems += amount;
            Debug.Log(gems);
        }
    }
}
