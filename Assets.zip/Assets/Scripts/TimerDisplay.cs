﻿ using UnityEngine;
 using System.Collections;
 using UnityEngine.UI;
 
 public class TimerDisplay : MonoBehaviour 
 {
     public Text timerLabel;
 
     private float time;
 
     void Update() 
     {
         time += Time.deltaTime;
         var seconds = (int)time % 60;//Use the euclidean division for the seconds.
         //update the label value
         timerLabel.text = string.Format ("{000}", seconds);
     }
 }