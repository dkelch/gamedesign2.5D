﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace UnityStandardAssets._2D
{
    public class PlayerCollision : MonoBehaviour
    {
        bool gem = false;
        private PlayerController pc;
        private PlayerHealth ph;
        private GemTracker gt;
        public string sameLevel;
        private Vector2 origin;
        // Use this for initialization
        void Start()
        {
            pc = GetComponent<PlayerController>();
            gt = GetComponent<GemTracker>();
            ph = GetComponent<PlayerHealth>();
            if (gt == null)
            {
                Debug.LogError("No GemTracker");  
            }
            origin = this.transform.position;
        }
        private void OnCollisionEnter2D(Collision2D collision)
        {
            //Debug.Log(collision.gameObject.tag);
            if (collision.gameObject.tag == "Enemy") //Tag any enemy with Enemy
            {
                ph.takeDamage(1);
                this.transform.position = origin;
                if (ph.currentLives == 0)
                {
                    SceneManager.LoadScene("Start Menu");
                }
            } 
            if(collision.gameObject.tag == "Gem") //Tag any collectable gems with Gem tag
            {
                //Debug.Log("Touched Gem");
                gt.GemCollect(1); //Increments the current gem amount by one
                Destroy(collision.gameObject);
            }
           // Debug.Log("Got contact");
            if(collision.contacts.Length > 0)
            {
                ContactPoint2D contact = collision.contacts[0];
                if(Vector3.Dot(contact.normal, Vector3.right) > 0.5)
                {
                    //Debug.Log("Left");
                    pc.hitWall = "Left";
                }

                else if(Vector3.Dot(contact.normal, Vector3.left) > 0.5)
                {
                    //Debug.Log("Right");
                    pc.hitWall = "Right";
                }

                else
                {
                    pc.hitWall = "None";
                }
            }
        }

        private void OnCollisionStay2D(Collision2D collision)
        {
            //Debug.Log(collision.collider.name);

            if (collision.gameObject.tag == "Cart") //Tag the cart with Cart
            {
                collision.gameObject.SendMessage("GemCollect", -1); //Clears gems currently held
                collision.gameObject.SendMessage("TotalGems", 1); //Tells TotalGems to add all current gems to total
            }
            
            // Debug.Log("Got contact");
            if(collision.contacts.Length > 0)
            {
                ContactPoint2D contact = collision.contacts[0];

                if(Vector3.Dot(contact.normal, Vector3.right) > 0.5)
                {
                    //Debug.Log("Left");
                    pc.hitWall = "Left";
                }

                else if(Vector3.Dot(contact.normal, Vector3.left) > 0.5)
                {
                    //Debug.Log("Right");
                    pc.hitWall = "Right";
                }

                else
                {
                    pc.hitWall = "None";
                }
            }
            
        }
    }
}
