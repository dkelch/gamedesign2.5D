﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpriteShadow : MonoBehaviour
{
    public Vector2 offset = new Vector2(-3,-3);

    private SpriteRenderer spriteRenderCaster;
    private SpriteRenderer spriteRenderShadow;

    private Transform transformCaster;
    private Transform transformShadow;
    public Material shadowMaterial;
    public Color shadowColor;

    // Start is called before the first frame update
    void Start()
    {
        transformCaster = transform;
        transformShadow = new GameObject().transform;
        transformShadow.parent = transformCaster;
        transformShadow.gameObject.name = "shadow";
        transformShadow.localRotation = Quaternion.identity;

        spriteRenderCaster = GetComponent<SpriteRenderer>();
        spriteRenderShadow = transformShadow.gameObject.AddComponent<SpriteRenderer>();

        spriteRenderShadow.material = shadowMaterial;
        spriteRenderShadow.color = shadowColor;
        spriteRenderShadow.sortingLayerName = spriteRenderCaster.sortingLayerName;
        spriteRenderShadow.sortingOrder = spriteRenderCaster.sortingOrder - 1;
    }

    // Update is called once per frame
    void LateUpdate()
    {
        transformShadow.position = new Vector2(transformCaster.position.x + offset.x,
            transformCaster.position.y + offset.y);
        spriteRenderShadow.sprite = spriteRenderCaster.sprite;
    }
}
