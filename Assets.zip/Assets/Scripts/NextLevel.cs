﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement; // This is very important if we want to restart the level
public class NextLevel : MonoBehaviour
{

    public AudioSource nextLevelSound;
    public string nextLevel;
    // Start is called before the first frame update
    void Start()
    {
        
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            //Debug.Log("Hit!");
            nextLevelSound.Play();
            SceneManager.LoadScene(nextLevel);//CHANGE SCENE NAME !!!!!!!!!!!!!!!!!!!!!!!!

        }
    }
        // Update is called once per frame
        void Update()
    {
        
    }
}
