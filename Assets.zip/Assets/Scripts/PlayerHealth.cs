﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

namespace UnityStandardAssets._2D
{
    public class PlayerHealth : MonoBehaviour
    {
        public int startingLives = 3;                            // The amount of lives the player starts the game with.
        public int currentLives;                                   // The current amount of lives the player has.                                // Reference to the UI's live display.
        PlayerController playerMovement;  
        PlayerCollision playerCollision;                            // Reference to the player's movement.
        public Text lives;

        void Awake()
        {
            // Setting up the references.
            playerCollision = GetComponent<PlayerCollision>();
            playerMovement = GetComponent<PlayerController>();
            lives = lives.GetComponent<Text>();
            // Set the initial health of the player.
            currentLives = startingLives;
            lives.text = string.Format("{0}",currentLives);
        }


        public void takeDamage(int damage)
        {
            currentLives -= damage;
            lives.text = string.Format("{0}",currentLives);
        }
    }
}
