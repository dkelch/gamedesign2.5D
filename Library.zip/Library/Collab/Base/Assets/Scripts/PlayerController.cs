﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

namespace UnityStandardAssets._2D
{
    public class PlayerController : MonoBehaviour
    {
        
        public float horizontalSpeed = 50f;
        public float jumpForce = 100f;
        public bool freezeRotation = true;
        private Vector2 offset;
        private Vector2 fwd;
        private GameObject clone;

        private Rigidbody2D rb;
        private Animator anim;
        
        private bool isGrounded;
        private bool facingRight = true;  // Determines the players current facing direction
        private bool done; //Set true if time is up

        // Use this for initialization
        private void Awake()
        {
            //Create component shorthand here
            rb = GetComponent<Rigidbody2D>();
            anim = GetComponent<Animator>();

            //Fill array
            //platforms = GameObject.FindGameObjectsWithTag("Ground");

            //Makes it so velocity doesn't knock over player
            if (freezeRotation)
            {

                rb.constraints = RigidbodyConstraints2D.FreezeRotation;

            }
            
        }

        // Update is called once per frame
        private void FixedUpdate()
        {

            
        }

        //Controls the players movement, calls other methods for each different movement type
        public void Move(float move, bool jump)
        {

            //Move the player
            rb.velocity = new Vector2(move * horizontalSpeed, rb.velocity.y);

            //The Speed animator parameter is set to the absolute value of the horizontal input
            //anim.SetFloat("Speed", Mathf.Abs(move));

            // If the player is able to bounce.
            if (jump && isGrounded == true)
            {

                Jump();

            }
)
            //If the input is moving the player right and the player is facing left...
            if (move > 0 && !facingRight)
            {

                // ... flip the player.
                Flip();

            }

            //Otherwise if the input is moving the player left and the player is facing right...
            else if (move < 0 && facingRight)
            {

                //Flips the player's avatar
                Flip();

            }

        }

        
        //Allows the character to bounce
        private void Jump()
        {

            //Add a vertical force to player and say they are not on the ground
            rb.AddForce(new Vector2(0f, jumpForce));
            isGrounded = false;

        }

        //Flips sprite when changing direction
        private void Flip()
        {

            //Switch the way the player is labelled as facing.
            facingRight = !facingRight;

            //Multiply the player's x local scale by -1.
            Vector3 theScale = transform.localScale;
            theScale.x *= -1;
            transform.localScale = theScale;

        }

    }

    
}
